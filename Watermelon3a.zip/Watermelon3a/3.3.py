﻿import matplotlib.pyplot as plt  # 导入matplot
import numpy as np  # 导入numpy
import pandas as pd  # 用于导入表格


def sigmoid(x):
    y = 1.0 / (1 + np.exp(-x))
    return y  # 构造sigmoid函数


# 梯度下降法
def gradDescent(X, y):
    N = X.shape[0]
    line = 0.05
    beta = np.ones((1, 3)) * 0.1  # 初始化矩阵，以1填充一个1行3列的矩阵
    z = X.dot(beta.T)  # 数组的点积

    for i in range(150):
        p1 = np.exp(z) / (1 + np.exp(z))  # 带入公式
        p = np.diag((p1 * (1 - p1)).reshape(N))  # 求其对角矩阵
        first_order = -np.sum(X * (y - p1), 0, keepdims=True)  # 每一列相加，压缩为一行
        beta -= first_order * line  # 每次更新
        z = X.dot(beta.T)

    l = np.sum(y * z + np.log(1 + np.exp(z)))  # 放入公式
    print(l)
    return beta


if __name__ == "__main__":
    workbook = pd.read_csv("watermelon_3a.csv", header=None)  # 导入表格
    workbook.insert(3, "3", 1)
    X = workbook.values[:, 1:-1]
    y = workbook.values[:, 4].reshape(-1, 1)
    positive_data = workbook.values[workbook.values[:, 4] == 1.0, :]
    negative_data = workbook.values[workbook.values[:, 4] == 0, :]
    plt.plot(positive_data[:, 1], positive_data[:, 2], 'b^')
plt.plot(negative_data[:, 1], negative_data[:, 2], 'r+')  # 绘制点
beta = gradDescent(X, y)  # 用梯度下降法求
grad_descent_left = -(beta[0, 0] * 0.1 + beta[0, 2]) / beta[0, 1]
grad_descent_right = -(beta[0, 0] * 0.9 + beta[0, 2]) / beta[0, 1]
plt.plot([0.1, 0.9], [grad_descent_left, grad_descent_right], 'y-')  # 画线
plt.xlabel('D')
plt.ylabel('S')
plt.title("Rate regression")
plt.show()

